package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.ScanWakeApplication
import com.example.alarm.AlarmScheduler
import com.example.data.SoundPreferences
import com.example.sound.SoundPlayerManager
import com.example.ui.ringing.AlarmRingingActivity

class AlarmService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private var soundPlayerManager: SoundPlayerManager? = null
    private var vibrator: Vibrator? = null
    private var isVibrating = false
    private var screenOffReceiver: BroadcastReceiver? = null

    private var currentAlarmId: Long = -1L
    private var preventTurnOff: Boolean = true

    override fun onCreate() {
        super.onCreate()
        soundPlayerManager = SoundPlayerManager(this)

        // Setup Vibrator
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        val action = intent.action
        if (action == ACTION_STOP_ALARM) {
            stopAlarmInternal()
            stopSelf()
            return START_NOT_STICKY
        }

        currentAlarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        val alarmLabel = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Scan Barcode to Dismiss"
        preventTurnOff = intent.getBooleanExtra(EXTRA_PREVENT_TURNOFF, true)

        acquireWakeLock()
        startForegroundNotification(alarmLabel)
        startAlarmAudio()
        startContinuousVibration()

        if (preventTurnOff) {
            registerScreenOffCountermeasure()
        }

        return START_STICKY
    }

    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            @Suppress("DEPRECATION")
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "ScanWake:AlarmServiceWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(30 * 60 * 1000L) // 30 mins max safety limit
            }
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                }
            }
        } catch (e: Exception) {
            Log.e("AlarmService", "Error releasing wake lock: ${e.message}")
        } finally {
            wakeLock = null
        }
    }

    private fun startForegroundNotification(label: String) {
        val ringingIntent = Intent(this, AlarmRingingActivity::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, currentAlarmId)
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            )
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            1001,
            ringingIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, ScanWakeApplication.CHANNEL_ALARM_RINGING)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("⏰ ALARM RINGING: $label")
            .setContentText("Turn-off protection active. Scan barcode to stop.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun startAlarmAudio() {
        val app = applicationContext as ScanWakeApplication
        val soundPrefs = app.soundPreferences
        val selectedTone = soundPrefs.getSoundType()
        val customPath = soundPrefs.getCustomSoundPath()
        val volume = soundPrefs.getAlarmVolume()
        val fadeIn = soundPrefs.getAlarmFadeIn()

        soundPlayerManager?.enforceMaxAlarmVolume()
        soundPlayerManager?.playTone(
            type = selectedTone,
            customFilePath = customPath,
            looping = true,
            volume = volume,
            fadeIn = fadeIn
        )
    }

    private fun startContinuousVibration() {
        if (isVibrating) return
        isVibrating = true

        val pattern = longArrayOf(0, 800, 300, 800, 300, 1200, 500)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (e: Exception) {
            Log.e("AlarmService", "Error starting vibration: ${e.message}")
        }
    }

    private fun registerScreenOffCountermeasure() {
        if (screenOffReceiver == null) {
            screenOffReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                        Log.w("AlarmService", "Screen turned off while alarm ringing! Reactivating screen immediately.")
                        // Wake screen right back up and bring ringing activity to front
                        acquireWakeLock()
                        soundPlayerManager?.enforceMaxAlarmVolume()

                        val wakeIntent = Intent(context, AlarmRingingActivity::class.java).apply {
                            putExtra(AlarmScheduler.EXTRA_ALARM_ID, currentAlarmId)
                            addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                            )
                        }
                        context?.startActivity(wakeIntent)
                    }
                }
            }
            registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        }
    }

    private fun stopAlarmInternal() {
        screenOffReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
                // Ignore if already unregistered
            }
            screenOffReceiver = null
        }

        try {
            vibrator?.cancel()
            isVibrating = false
        } catch (e: Exception) {
            Log.e("AlarmService", "Error stopping vibrator: ${e.message}")
        }

        soundPlayerManager?.stop()
        releaseWakeLock()
    }

    override fun onDestroy() {
        stopAlarmInternal()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val NOTIFICATION_ID = 2002
        const val ACTION_START_ALARM = "com.example.action.START_ALARM"
        const val ACTION_STOP_ALARM = "com.example.action.STOP_ALARM"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_PREVENT_TURNOFF = "extra_prevent_turnoff"
    }
}
