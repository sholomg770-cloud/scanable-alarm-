package com.example

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.alarm.AlarmScheduler
import com.example.receiver.AlarmReceiver
import com.example.ui.ringing.AlarmRingingActivity
import com.example.ui.screens.AlarmListScreen
import com.example.ui.screens.AntiTurnoffShieldInfoScreen
import com.example.ui.screens.BarcodeVaultScreen
import com.example.ui.screens.SoundSettingsScreen
import com.example.ui.theme.ScanWakeTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ScanWakeTheme {
                val snackbarHostState = remember { SnackbarHostState() }
                val scope = rememberCoroutineScope()
                var selectedTabIndex by remember { mutableIntStateOf(0) }

                // Runtime Permissions Request (Camera & Notifications)
                val permissionsLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { /* permissions evaluated */ }

                LaunchedEffect(Unit) {
                    val permissions = mutableListOf(Manifest.permission.CAMERA)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        permissions.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    permissionsLauncher.launch(permissions.toTypedArray())
                }

                fun triggerImmediateTestAlarm() {
                    scope.launch {
                        snackbarHostState.showSnackbar("Test Alarm triggering in 3 seconds! Get ready to test.")
                    }
                    val testIntent = Intent(this@MainActivity, AlarmRingingActivity::class.java).apply {
                        putExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
                        addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                        )
                    }
                    window.decorView.postDelayed({
                        startActivity(testIntent)
                    }, 3000L)
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Text(
                                    text = when (selectedTabIndex) {
                                        0 -> "ScanWake"
                                        1 -> "Barcode Vault"
                                        2 -> "Alarm Tones & Snooze"
                                        3 -> "Phone Turn-off Shield"
                                        else -> "ScanWake"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 19.sp
                                )
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background,
                                titleContentColor = MaterialTheme.colorScheme.onBackground
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ) {
                            NavigationBarItem(
                                selected = selectedTabIndex == 0,
                                onClick = { selectedTabIndex = 0 },
                                icon = { Icon(Icons.Default.Alarm, contentDescription = "Alarms") },
                                label = { Text("Alarms") },
                                modifier = Modifier.testTag("nav_tab_alarms"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )

                            NavigationBarItem(
                                selected = selectedTabIndex == 1,
                                onClick = { selectedTabIndex = 1 },
                                icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Vault") },
                                label = { Text("Vault") },
                                modifier = Modifier.testTag("nav_tab_vault"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )

                            NavigationBarItem(
                                selected = selectedTabIndex == 2,
                                onClick = { selectedTabIndex = 2 },
                                icon = { Icon(Icons.Default.MusicNote, contentDescription = "Sounds") },
                                label = { Text("Sounds") },
                                modifier = Modifier.testTag("nav_tab_sounds"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )

                            NavigationBarItem(
                                selected = selectedTabIndex == 3,
                                onClick = { selectedTabIndex = 3 },
                                icon = { Icon(Icons.Default.Security, contentDescription = "Shield") },
                                label = { Text("Shield") },
                                modifier = Modifier.testTag("nav_tab_shield"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                ) { innerPadding ->
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (selectedTabIndex) {
                            0 -> AlarmListScreen(
                                snackbarHostState = snackbarHostState,
                                onTriggerTestAlarm = { triggerImmediateTestAlarm() }
                            )
                            1 -> BarcodeVaultScreen(
                                snackbarHostState = snackbarHostState
                            )
                            2 -> SoundSettingsScreen(
                                snackbarHostState = snackbarHostState
                            )
                            3 -> AntiTurnoffShieldInfoScreen(
                                onTriggerTestAlarm = { triggerImmediateTestAlarm() }
                            )
                        }
                    }
                }
            }
        }
    }
}
