package com.example.sound

import android.content.Context
import com.example.data.SoundPreferences
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

object ToneAudioGenerator {
    private const val SAMPLE_RATE = 22050

    fun getToneFile(context: Context, type: String): File {
        val soundDir = File(context.filesDir, "tones").apply { mkdirs() }
        val file = File(soundDir, "$type.wav")
        if (!file.exists() || file.length() < 100) {
            generateToneFile(file, type)
        }
        return file
    }

    private fun generateToneFile(destination: File, type: String) {
        val durationSeconds = when (type) {
            SoundPreferences.TYPE_RADAR_PULSE -> 2.0
            SoundPreferences.TYPE_DIGITAL_BEEP -> 2.5
            SoundPreferences.TYPE_EMERGENCY_SIREN -> 3.0
            SoundPreferences.TYPE_ENERGETIC_WAKE -> 2.5
            else -> 2.0
        }

        val totalSamples = (SAMPLE_RATE * durationSeconds).toInt()
        val samples = ShortArray(totalSamples)

        when (type) {
            SoundPreferences.TYPE_RADAR_PULSE -> {
                // Two sharp radar pulses with decay
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val cycleTime = t % 1.0 // 1 sec loop
                    var sampleVal = 0.0
                    if (cycleTime < 0.25) {
                        val decay = 1.0 - (cycleTime / 0.25)
                        sampleVal = sin(2.0 * PI * 920.0 * cycleTime) * decay
                    } else if (cycleTime in 0.35..0.60) {
                        val decay = 1.0 - ((cycleTime - 0.35) / 0.25)
                        sampleVal = sin(2.0 * PI * 1380.0 * cycleTime) * decay
                    }
                    samples[i] = (sampleVal * 28000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            SoundPreferences.TYPE_DIGITAL_BEEP -> {
                // 4 sharp beeps followed by pause
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val cycleTime = t % 1.25
                    var isBeeping = false
                    // 4 beeps: 0-0.12, 0.2-0.32, 0.4-0.52, 0.6-0.72
                    for (b in 0..3) {
                        val start = b * 0.20
                        val end = start + 0.12
                        if (cycleTime in start..end) {
                            isBeeping = true
                            break
                        }
                    }
                    val sampleVal = if (isBeeping) {
                        sin(2.0 * PI * 2048.0 * t) * 0.95
                    } else 0.0
                    samples[i] = (sampleVal * 28000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            SoundPreferences.TYPE_EMERGENCY_SIREN -> {
                // Frequency modulated siren sweep 650Hz to 1450Hz
                var phase = 0.0
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    // 1.5s sweep period
                    val mod = (sin(2.0 * PI * (t / 1.5)) + 1.0) / 2.0 // 0.0 to 1.0
                    val freq = 650.0 + (mod * 800.0)
                    phase += 2.0 * PI * freq / SAMPLE_RATE
                    val sampleVal = sin(phase) * 0.95
                    samples[i] = (sampleVal * 28000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
            SoundPreferences.TYPE_ENERGETIC_WAKE -> {
                // Rhythmic beat + bright harmonic pulse
                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val beatTime = t % 0.5 // 120 bpm pulse
                    val beatDecay = (1.0 - (beatTime / 0.5)).coerceAtLeast(0.0)
                    val bass = sin(2.0 * PI * 140.0 * beatTime) * beatDecay
                    val chirp = sin(2.0 * PI * 880.0 * beatTime) * (beatDecay * beatDecay) * 0.5
                    val sampleVal = (bass + chirp).coerceIn(-1.0, 1.0)
                    samples[i] = (sampleVal * 28000).toInt().coerceIn(-32767, 32767).toShort()
                }
            }
        }

        writeWavFile(destination, samples, SAMPLE_RATE)
    }

    private fun writeWavFile(file: File, samples: ShortArray, sampleRate: Int) {
        val numChannels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * numChannels * (bitsPerSample / 8)
        val dataSize = samples.size * 2
        val totalSize = 36 + dataSize

        FileOutputStream(file).use { out ->
            val header = ByteBuffer.allocate(44).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                put("RIFF".toByteArray())
                putInt(totalSize)
                put("WAVE".toByteArray())
                put("fmt ".toByteArray())
                putInt(16) // Subchunk1Size for PCM
                putShort(1) // AudioFormat 1 = PCM
                putShort(numChannels.toShort())
                putInt(sampleRate)
                putInt(byteRate)
                putShort((numChannels * bitsPerSample / 8).toShort()) // BlockAlign
                putShort(bitsPerSample.toShort())
                put("data".toByteArray())
                putInt(dataSize)
            }
            out.write(header.array())

            val sampleBytes = ByteBuffer.allocate(dataSize).apply {
                order(ByteOrder.LITTLE_ENDIAN)
                for (sample in samples) {
                    putShort(sample)
                }
            }
            out.write(sampleBytes.array())
        }
    }
}
