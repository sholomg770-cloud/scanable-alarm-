package com.example.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.util.Log
import com.example.data.SoundPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class SoundPlayerManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var fadeInJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    fun playTone(
        type: String,
        customFilePath: String?,
        looping: Boolean,
        volume: Float = 1.0f,
        fadeIn: Boolean = false
    ) {
        stop()

        try {
            val player = MediaPlayer()
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            player.setAudioAttributes(attributes)
            player.isLooping = looping

            var prepared = false

            when (type) {
                SoundPreferences.TYPE_CUSTOM_FILE -> {
                    if (customFilePath != null) {
                        val file = File(customFilePath)
                        if (file.exists() && file.canRead()) {
                            player.setDataSource(customFilePath)
                            prepared = true
                        }
                    }
                    if (!prepared) {
                        Log.w("SoundPlayerManager", "Custom file not found, falling back to radar tone")
                        val fallback = ToneAudioGenerator.getToneFile(context, SoundPreferences.TYPE_RADAR_PULSE)
                        player.setDataSource(fallback.absolutePath)
                        prepared = true
                    }
                }
                SoundPreferences.TYPE_SYSTEM_DEFAULT -> {
                    val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                    if (alertUri != null) {
                        player.setDataSource(context, alertUri)
                        prepared = true
                    }
                }
                else -> {
                    val toneFile = ToneAudioGenerator.getToneFile(context, type)
                    player.setDataSource(toneFile.absolutePath)
                    prepared = true
                }
            }

            if (prepared) {
                if (fadeIn) {
                    val initialVol = (0.05f * volume).coerceAtLeast(0.02f)
                    player.setVolume(initialVol, initialVol)
                    player.prepare()
                    player.start()
                    mediaPlayer = player

                    // Gradually ramp up volume over 30 seconds (30 steps of 1 second)
                    fadeInJob = scope.launch {
                        val totalSteps = 30
                        for (step in 1..totalSteps) {
                            delay(1000L)
                            val progress = step / totalSteps.toFloat()
                            val curVol = initialVol + (volume - initialVol) * progress
                            try {
                                mediaPlayer?.setVolume(curVol, curVol)
                            } catch (e: Exception) {
                                break
                            }
                        }
                    }
                } else {
                    player.setVolume(volume, volume)
                    player.prepare()
                    player.start()
                    mediaPlayer = player
                }
            }
        } catch (e: Exception) {
            Log.e("SoundPlayerManager", "Error playing tone $type: ${e.message}", e)
        }
    }

    fun isPlaying(): Boolean {
        return try {
            mediaPlayer?.isPlaying == true
        } catch (e: Exception) {
            false
        }
    }

    fun stop() {
        fadeInJob?.cancel()
        fadeInJob = null

        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            Log.e("SoundPlayerManager", "Error stopping player: ${e.message}")
        } finally {
            mediaPlayer = null
        }
    }

    fun enforceMaxAlarmVolume() {
        try {
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxVol, 0)
        } catch (e: Exception) {
            Log.e("SoundPlayerManager", "Error setting alarm stream volume: ${e.message}")
        }
    }
}
