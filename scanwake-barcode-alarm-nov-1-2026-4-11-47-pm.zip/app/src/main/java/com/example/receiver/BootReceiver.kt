package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.ScanWakeApplication
import com.example.alarm.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            Log.d("BootReceiver", "Boot completed: restoring alarms")
            val app = context.applicationContext as ScanWakeApplication
            val pendingResult = goAsync()

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val alarms = app.database.alarmDao().getEnabledAlarmsSync()
                    for (alarm in alarms) {
                        AlarmScheduler.scheduleAlarm(context, alarm)
                    }
                    Log.d("BootReceiver", "Restored ${alarms.size} alarms")
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Error restoring alarms: ${e.message}")
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
