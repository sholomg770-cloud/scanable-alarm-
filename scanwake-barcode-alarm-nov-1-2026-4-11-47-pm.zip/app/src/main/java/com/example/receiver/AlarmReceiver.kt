package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.ScanWakeApplication
import com.example.alarm.AlarmScheduler
import com.example.service.AlarmService
import com.example.ui.ringing.AlarmRingingActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        Log.d("AlarmReceiver", "Received alarm trigger for ID: $alarmId")

        val app = context.applicationContext as ScanWakeApplication
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val alarm = app.database.alarmDao().getAlarmById(alarmId)
                val label = alarm?.label ?: "Time to Wake Up!"
                val preventTurnOff = alarm?.preventTurnOffShield ?: true

                // Start Foreground AlarmService
                val serviceIntent = Intent(context, AlarmService::class.java).apply {
                    action = AlarmService.ACTION_START_ALARM
                    putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
                    putExtra(AlarmService.EXTRA_ALARM_LABEL, label)
                    putExtra(AlarmService.EXTRA_PREVENT_TURNOFF, preventTurnOff)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }

                // Launch Ringing Activity directly over lockscreen
                val activityIntent = Intent(context, AlarmRingingActivity::class.java).apply {
                    putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    )
                }
                context.startActivity(activityIntent)

                // If one-off alarm, disable it. If repeating, schedule next occurrence
                if (alarm != null) {
                    if (!alarm.isRepeating()) {
                        app.database.alarmDao().setAlarmEnabled(alarm.id, false)
                    } else {
                        AlarmScheduler.scheduleAlarm(context, alarm)
                    }
                }
            } catch (e: Exception) {
                Log.e("AlarmReceiver", "Error processing alarm: ${e.message}", e)
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_FIRE_ALARM = "com.example.ACTION_FIRE_ALARM"
    }
}
