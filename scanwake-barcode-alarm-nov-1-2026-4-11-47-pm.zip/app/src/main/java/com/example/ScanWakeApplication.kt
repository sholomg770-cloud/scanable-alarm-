package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.AppDatabase
import com.example.data.SoundPreferences

class ScanWakeApplication : Application() {

    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val soundPreferences: SoundPreferences by lazy { SoundPreferences(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Alarm Ringing Channel (High priority, bypass DND)
            val alarmChannel = NotificationChannel(
                CHANNEL_ALARM_RINGING,
                "ScanWake Alarm Ringing",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent alarm notifications requiring barcode scan to dismiss"
                setSound(null, null) // Sound is handled by AlarmService MediaPlayer
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Upcoming Alarms Channel
            val statusChannel = NotificationChannel(
                CHANNEL_ALARM_STATUS,
                "Alarm Schedule Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows upcoming alarm times"
            }

            notificationManager.createNotificationChannel(alarmChannel)
            notificationManager.createNotificationChannel(statusChannel)
        }
    }

    companion object {
        const val CHANNEL_ALARM_RINGING = "scanwake_alarm_ringing_channel"
        const val CHANNEL_ALARM_STATUS = "scanwake_alarm_status_channel"

        lateinit var instance: ScanWakeApplication
            private set
    }
}
