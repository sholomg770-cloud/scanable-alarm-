package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ScanWakeApplication
import com.example.data.SoundPreferences
import com.example.sound.SoundPlayerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

@Composable
fun SoundSettingsScreen(
    snackbarHostState: SnackbarHostState
) {
    val context = LocalContext.current
    val app = context.applicationContext as ScanWakeApplication
    val soundPrefs = app.soundPreferences
    val scope = rememberCoroutineScope()

    val currentSoundType by soundPrefs.soundTypeFlow.collectAsState()
    val customSoundTitle by soundPrefs.customSoundTitleFlow.collectAsState()
    val alarmVolume by soundPrefs.alarmVolumeFlow.collectAsState()
    val snoozeDurationSeconds by soundPrefs.snoozeDurationSecondsFlow.collectAsState()
    val alarmFadeIn by soundPrefs.alarmFadeInFlow.collectAsState()

    val soundPlayerManager = remember { SoundPlayerManager(context) }
    var currentlyPlayingType by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            soundPlayerManager.stop()
        }
    }

    // Audio file picker contract: zero broad permissions required
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val displayName = getFileNameFromUri(context, uri) ?: "Selected Sound"
                    val destinationFile = File(context.filesDir, "custom_alarm_tone.dat")

                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(destinationFile).use { output ->
                            input.copyTo(output)
                        }
                    }

                    soundPrefs.setCustomSound(displayName, destinationFile.absolutePath)
                    withContext(Dispatchers.Main) {
                        snackbarHostState.showSnackbar("Custom sound '$displayName' set for all active alarms!")
                    }
                } catch (e: Exception) {
                    Log.e("SoundSettings", "Error importing audio: ${e.message}", e)
                    withContext(Dispatchers.Main) {
                        snackbarHostState.showSnackbar("Failed to import audio file: ${e.message}")
                    }
                }
            }
        }
    }

    fun playPreview(type: String) {
        if (currentlyPlayingType == type) {
            soundPlayerManager.stop()
            currentlyPlayingType = null
        } else {
            soundPlayerManager.stop()
            val customPath = if (type == SoundPreferences.TYPE_CUSTOM_FILE) soundPrefs.getCustomSoundPath() else null
            soundPlayerManager.playTone(type, customPath, looping = true, volume = alarmVolume)
            currentlyPlayingType = type
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Notice Banner: Applied to all active alarms
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Global Tone Setting",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "The selected sound will automatically be applied to all your active alarms.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Section: Built-in Alarm Sounds
        item {
            Text(
                text = "DEFAULT SELECTION",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
        }

        items(SoundPreferences.BUILT_IN_SOUNDS.size) { index ->
            val type = SoundPreferences.BUILT_IN_SOUNDS[index]
            val isSelected = currentSoundType == type
            val isPlaying = currentlyPlayingType == type

            val (title, subtitle) = when (type) {
                SoundPreferences.TYPE_RADAR_PULSE -> Pair("Radar Alert", "Sharp alternating high-urgency radar pulse")
                SoundPreferences.TYPE_DIGITAL_BEEP -> Pair("Digital Clock Beep", "Classic crisp 4-burst digital clock chime")
                SoundPreferences.TYPE_EMERGENCY_SIREN -> Pair("Emergency Siren", "Dynamic two-tone frequency modulated siren")
                SoundPreferences.TYPE_ENERGETIC_WAKE -> Pair("Energetic Wake Beat", "Lively morning tempo with bright chime")
                SoundPreferences.TYPE_SYSTEM_DEFAULT -> Pair("System Default Alarm", "Android default system alarm ringtone")
                else -> Pair("Sound", "")
            }

            ToneItemCard(
                title = title,
                subtitle = subtitle,
                isSelected = isSelected,
                isPlaying = isPlaying,
                onSelect = {
                    soundPrefs.setSoundType(type)
                    scope.launch {
                        snackbarHostState.showSnackbar("Tone '$title' applied to all alarms")
                    }
                },
                onTogglePlay = { playPreview(type) }
            )
        }

        // Section: Custom File From Device
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "CUSTOM SOUND FILE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
        }

        item {
            val isCustomSelected = currentSoundType == SoundPreferences.TYPE_CUSTOM_FILE
            val isCustomPlaying = currentlyPlayingType == SoundPreferences.TYPE_CUSTOM_FILE
            val hasCustomFile = soundPrefs.getCustomSoundPath() != null

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(
                        width = if (isCustomSelected) 2.dp else 1.dp,
                        color = if (isCustomSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp)
                    ),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCustomSelected) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    else MaterialTheme.colorScheme.surface
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isCustomSelected,
                            onClick = {
                                if (hasCustomFile) {
                                    soundPrefs.setSoundType(SoundPreferences.TYPE_CUSTOM_FILE)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Custom audio applied to all alarms")
                                    }
                                } else {
                                    audioPickerLauncher.launch(arrayOf("audio/*"))
                                }
                            },
                            modifier = Modifier.testTag("radio_custom_sound")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Custom Device File",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (hasCustomFile) customSoundTitle else "No file selected yet",
                                fontSize = 13.sp,
                                color = if (hasCustomFile) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (hasCustomFile) {
                            FilledIconButton(
                                onClick = { playPreview(SoundPreferences.TYPE_CUSTOM_FILE) },
                                modifier = Modifier
                                    .size(42.dp)
                                    .testTag("preview_custom_audio_button"),
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = if (isCustomPlaying) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Icon(
                                    imageVector = if (isCustomPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Preview Custom",
                                    tint = Color.Black
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            audioPickerLauncher.launch(arrayOf("audio/*"))
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("select_device_audio_file_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (hasCustomFile) "Choose Different Audio File" else "Select Sound File from Storage",
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Section: Alarm Volume
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ALARM PLAYBACK VOLUME",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Ringing Volume",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = "${(alarmVolume * 100).toInt()}%",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Slider(
                        value = alarmVolume,
                        onValueChange = { soundPrefs.setAlarmVolume(it) },
                        valueRange = 0.2f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("alarm_volume_slider")
                    )

                    Text(
                        text = "Note: While an alarm is ringing, Phone Turn-off Shield continuously restores volume to maximum to prevent silent dismissal.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Section: Alarm Fade-In (Gentle Wakeup)
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ALARM FADE-IN",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "Gradual Volume Ramp (30s)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Gradually increases volume over 30 seconds rather than starting at full blast.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Switch(
                        checked = alarmFadeIn,
                        onCheckedChange = {
                            soundPrefs.setAlarmFadeIn(it)
                            scope.launch {
                                snackbarHostState.showSnackbar(
                                    if (it) "Alarm Fade-in enabled (30-second volume ramp)"
                                    else "Alarm Fade-in disabled (Immediate volume)"
                                )
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("switch_alarm_fade_in")
                    )
                }
            }
        }

        // Section: Snooze Duration Configuration
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "SNOOZE DURATION",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Snooze,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Snooze Time",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "When the alarm rings, tapping 'Snooze' will silence it for this duration before sounding again.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    val snoozeOptions = listOf(
                        Pair(30, "30s"),
                        Pair(60, "1 min"),
                        Pair(180, "3 min"),
                        Pair(300, "5 min"),
                        Pair(600, "10 min")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        snoozeOptions.forEach { (seconds, label) ->
                            val isSelected = snoozeDurationSeconds == seconds
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable {
                                        soundPrefs.setSnoozeDurationSeconds(seconds)
                                        scope.launch {
                                            snackbarHostState.showSnackbar("Snooze duration set to $label")
                                        }
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
fun ToneItemCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    isPlaying: Boolean,
    onSelect: () -> Unit,
    onTogglePlay: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onSelect)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                modifier = Modifier.testTag("radio_tone_${title.replace(" ", "_")}")
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            FilledIconButton(
                onClick = onTogglePlay,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("preview_tone_${title.replace(" ", "_")}"),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (isPlaying) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primaryContainer,
                    contentColor = if (isPlaying) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = "Preview $title"
                )
            }
        }
    }
}

private fun getFileNameFromUri(context: Context, uri: Uri): String? {
    var name: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    name = it.getString(index)
                }
            }
        }
    }
    if (name == null) {
        name = uri.path?.let { p ->
            val cut = p.lastIndexOf('/')
            if (cut != -1) p.substring(cut + 1) else p
        }
    }
    return name
}
