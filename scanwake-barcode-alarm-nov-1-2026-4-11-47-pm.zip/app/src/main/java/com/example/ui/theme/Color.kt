package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AmberPrimary = Color(0xFFFF8F00)
val AmberOnPrimary = Color(0xFF000000)
val AmberContainer = Color(0xFFFFD180)
val AmberOnContainer = Color(0xFF331B00)

val CyanSecondary = Color(0xFF00E5FF)
val CyanOnSecondary = Color(0xFF002026)
val CyanContainer = Color(0xFF004D59)
val CyanOnContainer = Color(0xFFB2EBF2)

val AlarmRed = Color(0xFFFF3D00)
val AlarmRedContainer = Color(0xFF3E0A00)

val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF21262D)
val DarkOnSurface = Color(0xFFF0F6FC)
val DarkOnSurfaceVariant = Color(0xFF8B949E)

val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFECEFF1)
val LightOnSurface = Color(0xFF1A1C1E)
val LightOnSurfaceVariant = Color(0xFF45464F)
