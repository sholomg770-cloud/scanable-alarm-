package com.example.ui.ringing

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.CameraBarcodeScanner
import com.example.data.model.AlarmEntity
import com.example.data.model.BarcodeEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AlarmRingingScreen(
    alarm: AlarmEntity?,
    targetBarcode: BarcodeEntity?,
    snoozeDisplay: String = "1 minute",
    onSnoozeAlarm: () -> Unit = {},
    onDismissAlarm: () -> Unit,
    onFinishActivity: () -> Unit
) {
    var isDismissed by remember { mutableStateOf(false) }
    var scanErrorMessage by remember { mutableStateOf<String?>(null) }
    var showManualInputDialog by remember { mutableStateOf(false) }
    var showEmergencyDialog by remember { mutableStateOf(false) }
    var manualInputText by remember { mutableStateOf("") }

    var currentTimeString by remember {
        mutableStateOf(SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()))
    }

    LaunchedEffect(Unit) {
        while (!isDismissed) {
            currentTimeString = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    // Pulse animation for alarm bell
    val infiniteTransition = rememberInfiniteTransition(label = "AlarmPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AlarmScale"
    )

    fun verifyCode(scanned: String) {
        val trimmed = scanned.trim()
        val targetCode = targetBarcode?.code?.trim()

        if (targetCode.isNullOrBlank() || trimmed.equals(targetCode, ignoreCase = true)) {
            // SUCCESS!
            isDismissed = true
            scanErrorMessage = null
            onDismissAlarm()
        } else {
            scanErrorMessage = "Scanned: $trimmed\nExpected: $targetCode (${targetBarcode.name})"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = if (isDismissed) listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364))
                    else listOf(Color(0xFF1E0A00), Color(0xFF12141A), Color(0xFF0A0C10))
                )
            )
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        if (isDismissed) {
            // Success Screen
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF10B981).copy(alpha = 0.2f))
                        .border(3.dp, Color(0xFF10B981), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(64.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Barcode Verified!",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Good morning! You successfully unlocked the alarm with ${targetBarcode?.name ?: "your registered barcode"}.",
                    color = Color(0xFFD1D5DB),
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )

                Spacer(modifier = Modifier.height(36.dp))

                Button(
                    onClick = onFinishActivity,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(54.dp)
                        .testTag("dismiss_success_button")
                ) {
                    Text(
                        text = "I'm Awake! Open App",
                        color = Color.Black,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            // Ringing & Scanner View
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Anti-turnoff badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x33FF3D00))
                        .border(1.dp, Color(0xFFFF3D00), RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = Color(0xFFFF3D00),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Turn-off Shield Active • Scan Required",
                        color = Color(0xFFFF8A80),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Time Display
                Text(
                    text = currentTimeString,
                    color = Color.White,
                    fontSize = 42.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.scale(pulseScale)
                )

                Text(
                    text = alarm?.label?.ifBlank { "Scan Barcode to Dismiss" } ?: "Scan Barcode to Dismiss",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Target Barcode Instruction Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2430))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = "Target: ${targetBarcode?.name ?: "Any Registered Barcode"}",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = targetBarcode?.code?.let { "Match Code: $it" } ?: "Scan your bathroom/kitchen barcode",
                                color = Color(0xFF9CA3AF),
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Live Camera Barcode Scanner Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                ) {
                    CameraBarcodeScanner(
                        onBarcodeScanned = { code, _ ->
                            verifyCode(code)
                        },
                        modifier = Modifier.fillMaxSize(),
                        isScanningActive = !isDismissed,
                        overlayLabel = "Align barcode within red beam"
                    )
                }

                // Error Notification if wrong barcode scanned
                AnimatedVisibility(
                    visible = scanErrorMessage != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0x4DFF3D00))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = "Error",
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = scanErrorMessage ?: "",
                                color = Color(0xFFFFCDD2),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Snooze Button
                Button(
                    onClick = onSnoozeAlarm,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("snooze_alarm_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF242C3D),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Snooze,
                        contentDescription = "Snooze",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Snooze ($snoozeDisplay)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Alternate Input Options (Manual Code & Emergency Bypass)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showManualInputDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("manual_barcode_input_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Keyboard,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Type Code", fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = { showEmergencyDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("emergency_bypass_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFFFFA726)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Emergency", fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Manual Barcode Input Dialog
        if (showManualInputDialog) {
            AlertDialog(
                onDismissRequest = { showManualInputDialog = false },
                title = { Text("Enter Barcode Value", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            text = "If camera cannot scan, type or paste the exact barcode value below:",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = manualInputText,
                            onValueChange = { manualInputText = it },
                            label = { Text("Barcode Number/Text") },
                            placeholder = { Text(targetBarcode?.code ?: "e.g. 79400262108") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("manual_code_text_field")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showManualInputDialog = false
                            verifyCode(manualInputText)
                        },
                        modifier = Modifier.testTag("submit_manual_code_button")
                    ) {
                        Text("Verify & Turn Off")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showManualInputDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Emergency Bypass Dialog (Math Challenge)
        if (showEmergencyDialog) {
            EmergencyBypassDialog(
                onDismissRequest = { showEmergencyDialog = false },
                onBypassApproved = {
                    showEmergencyDialog = false
                    isDismissed = true
                    onDismissAlarm()
                }
            )
        }
    }
}

@Composable
fun EmergencyBypassDialog(
    onDismissRequest: () -> Unit,
    onBypassApproved: () -> Unit
) {
    val totalRequired = 15

    // Helper data class for math problem
    data class MathProblem(val text: String, val answer: Int)

    fun generateProblem(index: Int): MathProblem {
        val type = index % 3
        return when (type) {
            0 -> {
                val a = (11..25).random()
                val b = (3..9).random()
                val c = (12..40).random()
                MathProblem("($a × $b) + $c", (a * b) + c)
            }
            1 -> {
                val a = (40..99).random()
                val b = (25..65).random()
                val c = (10..30).random()
                MathProblem("$a + $b - $c", a + b - c)
            }
            else -> {
                val a = (12..20).random()
                val b = (4..8).random()
                val c = (5..15).random()
                MathProblem("($a × $b) - $c", (a * b) - c)
            }
        }
    }

    var currentProblemIndex by remember { mutableStateOf(0) }
    var currentProblem by remember { mutableStateOf(generateProblem(0)) }
    var answerInput by remember { mutableStateOf("") }
    var mathError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        icon = {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Emergency",
                tint = Color(0xFFFFA726),
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "Emergency Bypass (${currentProblemIndex + 1}/$totalRequired)",
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Solve all 15 math problems to turn off the alarm without scanning your barcode:",
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Progress Bar for 15 problems
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { (currentProblemIndex) / totalRequired.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "$currentProblemIndex of $totalRequired solved",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Problem Equation
                Text(
                    text = "${currentProblem.text} = ?",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = answerInput,
                    onValueChange = {
                        answerInput = it
                        mathError = false
                    },
                    label = { Text("Problem ${currentProblemIndex + 1} Answer") },
                    isError = mathError,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("math_bypass_input")
                )

                if (mathError) {
                    Text(
                        text = "Incorrect answer! Try again.",
                        color = Color.Red,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = answerInput.trim().toIntOrNull()
                    if (parsed != null && parsed == currentProblem.answer) {
                        val nextIndex = currentProblemIndex + 1
                        if (nextIndex >= totalRequired) {
                            onBypassApproved()
                        } else {
                            currentProblemIndex = nextIndex
                            currentProblem = generateProblem(nextIndex)
                            answerInput = ""
                            mathError = false
                        }
                    } else {
                        mathError = true
                    }
                },
                modifier = Modifier.testTag("submit_bypass_button")
            ) {
                Text(
                    if (currentProblemIndex + 1 == totalRequired) "Finish & Turn Off"
                    else "Next Problem (${currentProblemIndex + 1}/$totalRequired)"
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Back to Scanner")
            }
        }
    )
}
