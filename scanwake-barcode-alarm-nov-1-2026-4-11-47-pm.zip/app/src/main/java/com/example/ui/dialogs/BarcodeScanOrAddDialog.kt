package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.CameraBarcodeScanner

@Composable
fun BarcodeScanOrAddDialog(
    onDismiss: () -> Unit,
    onBarcodeSaved: (name: String, code: String, format: String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Camera Scan, 1 = Manual Input
    var barcodeName by remember { mutableStateOf("") }
    var scannedCode by remember { mutableStateOf("") }
    var detectedFormat by remember { mutableStateOf("BARCODE") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Register Wakeup Barcode",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Camera Scan") },
                        icon = { Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Manual Type") },
                        icon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (selectedTab == 0) {
                    // Live camera scanner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        CameraBarcodeScanner(
                            onBarcodeScanned = { code, format ->
                                scannedCode = code
                                detectedFormat = format
                                if (barcodeName.isBlank()) {
                                    barcodeName = "Bathroom Item ($format)"
                                }
                            },
                            modifier = Modifier.fillMaxSize(),
                            overlayLabel = if (scannedCode.isBlank()) "Point at any barcode" else "Scanned!"
                        )
                    }

                    if (scannedCode.isNotBlank()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x3310B981))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Code: $scannedCode ($detectedFormat)",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else {
                    // Manual Input
                    OutlinedTextField(
                        value = scannedCode,
                        onValueChange = {
                            scannedCode = it
                            errorMessage = null
                        },
                        label = { Text("Barcode / QR Code String") },
                        placeholder = { Text("e.g. 79400262108 or custom text") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_barcode_code_field")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Item Nickname Input
                OutlinedTextField(
                    value = barcodeName,
                    onValueChange = {
                        barcodeName = it
                        errorMessage = null
                    },
                    label = { Text("Item Name / Location") },
                    placeholder = { Text("e.g. Bathroom Toothpaste 🪥") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_barcode_name_field")
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (scannedCode.isBlank()) {
                        errorMessage = "Please scan or enter a barcode value"
                    } else if (barcodeName.isBlank()) {
                        errorMessage = "Please enter an item name"
                    } else {
                        onBarcodeSaved(barcodeName.trim(), scannedCode.trim(), detectedFormat)
                    }
                },
                modifier = Modifier.testTag("save_barcode_button")
            ) {
                Text("Save to Vault")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
