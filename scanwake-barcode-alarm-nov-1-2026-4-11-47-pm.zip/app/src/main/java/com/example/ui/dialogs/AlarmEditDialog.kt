package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerDefaults
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlarmEntity
import com.example.data.model.BarcodeEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmEditDialog(
    initialAlarm: AlarmEntity? = null,
    barcodes: List<BarcodeEntity>,
    onDismiss: () -> Unit,
    onSave: (
        timeHour: Int,
        timeMinute: Int,
        label: String,
        repeatDays: Int,
        targetBarcodeId: Long?,
        vibrate: Boolean,
        preventTurnOffShield: Boolean
    ) -> Unit
) {
    val timePickerState = rememberTimePickerState(
        initialHour = initialAlarm?.timeHour ?: 7,
        initialMinute = initialAlarm?.timeMinute ?: 0,
        is24Hour = false
    )

    var label by remember { mutableStateOf(initialAlarm?.label ?: "Wake Up") }
    var repeatDays by remember { mutableIntStateOf(initialAlarm?.repeatDays ?: 0b0011111) } // Default weekdays
    var selectedBarcodeId by remember { mutableStateOf(initialAlarm?.targetBarcodeId) }
    var vibrate by remember { mutableStateOf(initialAlarm?.vibrate ?: true) }
    var preventTurnOffShield by remember { mutableStateOf(initialAlarm?.preventTurnOffShield ?: true) }

    var barcodeDropdownExpanded by remember { mutableStateOf(false) }

    val daysLabels = listOf(
        Pair(0, "M"),
        Pair(1, "T"),
        Pair(2, "W"),
        Pair(3, "T"),
        Pair(4, "F"),
        Pair(5, "S"),
        Pair(6, "S")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialAlarm == null) "Set New Barcode Alarm" else "Edit Alarm",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Material 3 TimePicker
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    TimePicker(
                        state = timePickerState,
                        colors = TimePickerDefaults.colors(
                            clockDialColor = MaterialTheme.colorScheme.surfaceVariant,
                            selectorColor = MaterialTheme.colorScheme.primary,
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Repeat Days Selection Chips
                Text(
                    text = "Repeat Days",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    daysLabels.forEach { (index, dayInitial) ->
                        val isDaySelected = (repeatDays and (1 shl index)) != 0
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isDaySelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable {
                                    repeatDays = if (isDaySelected) {
                                        repeatDays and (1 shl index).inv()
                                    } else {
                                        repeatDays or (1 shl index)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = dayInitial,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isDaySelected) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Label Input
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Alarm Label") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("alarm_label_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Barcode Selector Dropdown
                Text(
                    text = "Barcode Required to Dismiss",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                val selectedBarcodeName = if (selectedBarcodeId == null) {
                    "Any Registered Barcode"
                } else {
                    barcodes.find { it.id == selectedBarcodeId }?.name ?: "Any Registered Barcode"
                }

                ExposedDropdownMenuBox(
                    expanded = barcodeDropdownExpanded,
                    onExpandedChange = { barcodeDropdownExpanded = !barcodeDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedBarcodeName,
                        onValueChange = {},
                        readOnly = true,
                        leadingIcon = {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = barcodeDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("barcode_selector_dropdown")
                    )

                    ExposedDropdownMenu(
                        expanded = barcodeDropdownExpanded,
                        onDismissRequest = { barcodeDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Any Registered Barcode") },
                            onClick = {
                                selectedBarcodeId = null
                                barcodeDropdownExpanded = false
                            }
                        )
                        barcodes.forEach { barcode ->
                            DropdownMenuItem(
                                text = { Text("${barcode.name} (${barcode.code})") },
                                onClick = {
                                    selectedBarcodeId = barcode.id
                                    barcodeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Turn-off Shield Toggle
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Phone Turn-off Shield",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Blocks power menu & screen turnoff until scanned",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Switch(
                            checked = preventTurnOffShield,
                            onCheckedChange = { preventTurnOffShield = it },
                            modifier = Modifier.testTag("switch_turnoff_shield")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Vibration Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Vibrate while ringing", fontSize = 14.sp)
                    }
                    Switch(
                        checked = vibrate,
                        onCheckedChange = { vibrate = it },
                        modifier = Modifier.testTag("switch_vibrate")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        timePickerState.hour,
                        timePickerState.minute,
                        label.ifBlank { "Wake Up" },
                        repeatDays,
                        selectedBarcodeId,
                        vibrate,
                        preventTurnOffShield
                    )
                },
                modifier = Modifier.testTag("save_alarm_dialog_button")
            ) {
                Text("Save Alarm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
