package com.example.ui.ringing

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.MainActivity
import com.example.ScanWakeApplication
import com.example.alarm.AlarmScheduler
import com.example.data.model.AlarmEntity
import com.example.data.model.BarcodeEntity
import com.example.service.AlarmService
import com.example.ui.theme.ScanWakeTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AlarmRingingActivity : ComponentActivity() {

    private var alarmId: Long = -1L
    private var isAlarmActive = true
    private lateinit var audioManager: AudioManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        setupLockscreenBypass()
        setupImmersiveStickyMode()
        setupBackHandler()

        loadAlarmData()
    }

    private fun setupLockscreenBypass() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setupImmersiveStickyMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Prevent dismiss via back button while alarm is ringing
                enforceMaxVolume()
            }
        })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isAlarmActive) {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_MUTE,
                KeyEvent.KEYCODE_VOLUME_UP -> {
                    enforceMaxVolume()
                    return true // Consume volume button events to block muting
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isAlarmActive) {
            // Re-bring to front if user attempts to leave before scanning barcode
            val reIntent = Intent(this, AlarmRingingActivity::class.java).apply {
                putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
            }
            startActivity(reIntent)
        }
    }

    private fun enforceMaxVolume() {
        try {
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadAlarmData() {
        val app = applicationContext as ScanWakeApplication
        CoroutineScope(Dispatchers.IO).launch {
            val alarm = if (alarmId != -1L) {
                app.database.alarmDao().getAlarmById(alarmId)
            } else null

            val targetBarcode = if (alarm?.targetBarcodeId != null) {
                app.database.barcodeDao().getBarcodeById(alarm.targetBarcodeId)
            } else null

            val appSettings = app.soundPreferences
            val snoozeSecs = appSettings.getSnoozeDurationSeconds()
            val snoozeDisplay = appSettings.getSnoozeDurationDisplay(snoozeSecs)

            withContext(Dispatchers.Main) {
                renderScreen(alarm, targetBarcode, snoozeSecs, snoozeDisplay)
            }
        }
    }

    private fun renderScreen(
        alarm: AlarmEntity?,
        targetBarcode: BarcodeEntity?,
        snoozeSeconds: Int,
        snoozeDisplay: String
    ) {
        setContent {
            ScanWakeTheme {
                AlarmRingingScreen(
                    alarm = alarm,
                    targetBarcode = targetBarcode,
                    snoozeDisplay = snoozeDisplay,
                    onSnoozeAlarm = {
                        isAlarmActive = false
                        stopAlarmService()
                        AlarmScheduler.scheduleSnooze(this, alarmId, snoozeSeconds)
                        finish()
                    },
                    onDismissAlarm = {
                        isAlarmActive = false
                        stopAlarmService()
                    },
                    onFinishActivity = {
                        finish()
                    }
                )
            }
        }
    }

    private fun stopAlarmService() {
        val stopIntent = Intent(this, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP_ALARM
        }
        startService(stopIntent)
    }
}
