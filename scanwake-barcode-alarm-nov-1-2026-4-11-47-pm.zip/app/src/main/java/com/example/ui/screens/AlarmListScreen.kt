package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AlarmOn
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ScanWakeApplication
import com.example.alarm.AlarmScheduler
import com.example.data.model.AlarmEntity
import com.example.data.model.BarcodeEntity
import com.example.ui.dialogs.AlarmEditDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AlarmListScreen(
    snackbarHostState: SnackbarHostState,
    onTriggerTestAlarm: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as ScanWakeApplication
    val scope = rememberCoroutineScope()

    val alarms by app.database.alarmDao().getAllAlarms().collectAsState(initial = emptyList())
    val barcodes by app.database.barcodeDao().getAllBarcodes().collectAsState(initial = emptyList())

    var showCreateDialog by remember { mutableStateOf(false) }
    var editingAlarm by remember { mutableStateOf<AlarmEntity?>(null) }
    var deletingAlarm by remember { mutableStateOf<AlarmEntity?>(null) }

    // Calculate next upcoming alarm time
    val nextAlarm = alarms.filter { it.isEnabled }.minByOrNull {
        AlarmScheduler.calculateNextTriggerTime(it.timeHour, it.timeMinute, it.repeatDays)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))

                // Next Alarm Countdown Header Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (nextAlarm != null) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AlarmOn,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (nextAlarm != null) "Next Alarm" else "No Alarms Set",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = nextAlarm?.formattedTime() ?: "All alarms disabled",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (nextAlarm != null) MaterialTheme.colorScheme.primary else Color.Gray
                                    )
                                }
                            }

                            // Quick test button
                            OutlinedButton(
                                onClick = onTriggerTestAlarm,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("quick_test_alarm_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Test (3s)", fontSize = 12.sp)
                            }
                        }

                        if (nextAlarm != null) {
                            val targetName = if (nextAlarm.targetBarcodeId != null) {
                                barcodes.find { it.id == nextAlarm.targetBarcodeId }?.name ?: "Barcode"
                            } else "Any registered barcode"

                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Requires: $targetName to turn off",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            if (alarms.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No Alarms Created",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap the + button below to create your first wake-up alarm.",
                            fontSize = 14.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                items(alarms, key = { it.id }) { alarm ->
                    val boundBarcode = barcodes.find { it.id == alarm.targetBarcodeId }

                    AlarmCard(
                        alarm = alarm,
                        boundBarcode = boundBarcode,
                        onToggle = { isEnabled ->
                            scope.launch(Dispatchers.IO) {
                                app.database.alarmDao().setAlarmEnabled(alarm.id, isEnabled)
                                if (isEnabled) {
                                    AlarmScheduler.scheduleAlarm(context, alarm.copy(isEnabled = true))
                                } else {
                                    AlarmScheduler.cancelAlarm(context, alarm.id)
                                }
                            }
                        },
                        onClick = { editingAlarm = alarm },
                        onDelete = { deletingAlarm = alarm }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp)) // Padding for FAB
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = { showCreateDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("fab_create_alarm"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.Black
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Create Alarm", modifier = Modifier.size(28.dp))
        }

        // Create Alarm Dialog
        if (showCreateDialog) {
            AlarmEditDialog(
                initialAlarm = null,
                barcodes = barcodes,
                onDismiss = { showCreateDialog = false },
                onSave = { hour, minute, label, repeatDays, targetBarcodeId, vibrate, preventShield ->
                    scope.launch(Dispatchers.IO) {
                        val newAlarm = AlarmEntity(
                            timeHour = hour,
                            timeMinute = minute,
                            label = label,
                            isEnabled = true,
                            repeatDays = repeatDays,
                            targetBarcodeId = targetBarcodeId,
                            vibrate = vibrate,
                            preventTurnOffShield = preventShield
                        )
                        val id = app.database.alarmDao().insertAlarm(newAlarm)
                        AlarmScheduler.scheduleAlarm(context, newAlarm.copy(id = id))

                        withContext(Dispatchers.Main) {
                            showCreateDialog = false
                            snackbarHostState.showSnackbar("Alarm set for ${newAlarm.formattedTime()}")
                        }
                    }
                }
            )
        }

        // Edit Alarm Dialog
        editingAlarm?.let { alarmToEdit ->
            AlarmEditDialog(
                initialAlarm = alarmToEdit,
                barcodes = barcodes,
                onDismiss = { editingAlarm = null },
                onSave = { hour, minute, label, repeatDays, targetBarcodeId, vibrate, preventShield ->
                    scope.launch(Dispatchers.IO) {
                        val updated = alarmToEdit.copy(
                            timeHour = hour,
                            timeMinute = minute,
                            label = label,
                            repeatDays = repeatDays,
                            targetBarcodeId = targetBarcodeId,
                            vibrate = vibrate,
                            preventTurnOffShield = preventShield
                        )
                        app.database.alarmDao().updateAlarm(updated)
                        if (updated.isEnabled) {
                            AlarmScheduler.scheduleAlarm(context, updated)
                        } else {
                            AlarmScheduler.cancelAlarm(context, updated.id)
                        }

                        withContext(Dispatchers.Main) {
                            editingAlarm = null
                            snackbarHostState.showSnackbar("Alarm updated")
                        }
                    }
                }
            )
        }

        // Delete Alarm Confirmation Dialog
        deletingAlarm?.let { alarmToDelete ->
            AlertDialog(
                onDismissRequest = { deletingAlarm = null },
                title = { Text("Delete Alarm?") },
                text = { Text("Are you sure you want to delete '${alarmToDelete.label}' (${alarmToDelete.formattedTime()})?") },
                confirmButton = {
                    Button(
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                AlarmScheduler.cancelAlarm(context, alarmToDelete.id)
                                app.database.alarmDao().deleteAlarm(alarmToDelete)
                                withContext(Dispatchers.Main) {
                                    deletingAlarm = null
                                    snackbarHostState.showSnackbar("Alarm deleted")
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("confirm_delete_alarm_button")
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { deletingAlarm = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun AlarmCard(
    alarm: AlarmEntity,
    boundBarcode: BarcodeEntity?,
    onToggle: (Boolean) -> Unit,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = if (alarm.isEnabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                else Color.Transparent,
                shape = RoundedCornerShape(18.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = alarm.formattedTime(),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif,
                        color = if (alarm.isEnabled) MaterialTheme.colorScheme.onSurface else Color.Gray
                    )
                    Text(
                        text = alarm.label,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (alarm.isEnabled) MaterialTheme.colorScheme.primary else Color.Gray
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = alarm.isEnabled,
                        onCheckedChange = onToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("switch_alarm_${alarm.id}")
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_alarm_${alarm.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Alarm",
                            tint = Color.Gray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details and Barcode tag row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Repeat Days
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = alarm.repeatDaysSummary(),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Target Barcode Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = boundBarcode?.name ?: "Any Barcode",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                if (alarm.preventTurnOffShield) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x26FF3D00))
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Shield Active",
                            tint = Color(0xFFFF5252),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }
    }
}
