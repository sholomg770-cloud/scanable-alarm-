package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timeHour: Int,
    val timeMinute: Int,
    val label: String = "Wake Up",
    val isEnabled: Boolean = true,
    val repeatDays: Int = 0, // bitmask: bit0=Mon .. bit6=Sun; 0 = once
    val targetBarcodeId: Long? = null, // null = any registered barcode
    val vibrate: Boolean = true,
    val preventTurnOffShield: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun isRepeating(): Boolean = repeatDays > 0

    fun isDaySelected(dayIndex: Int): Boolean { // dayIndex 0=Mon .. 6=Sun
        return (repeatDays and (1 shl dayIndex)) != 0
    }

    fun formattedTime(is24Hour: Boolean = false): String {
        return if (is24Hour) {
            String.format("%02d:%02d", timeHour, timeMinute)
        } else {
            val hourIn12 = if (timeHour % 12 == 0) 12 else timeHour % 12
            val amPm = if (timeHour < 12) "AM" else "PM"
            String.format("%d:%02d %s", hourIn12, timeMinute, amPm)
        }
    }

    fun repeatDaysSummary(): String {
        if (repeatDays == 0) return "Once"
        if (repeatDays == 0b1111111) return "Every day"
        if (repeatDays == 0b0011111) return "Weekdays (Mon-Fri)"
        if (repeatDays == 0b1100000) return "Weekends (Sat-Sun)"

        val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        val selected = mutableListOf<String>()
        for (i in 0..6) {
            if (isDaySelected(i)) selected.add(names[i])
        }
        return selected.joinToString(", ")
    }
}
