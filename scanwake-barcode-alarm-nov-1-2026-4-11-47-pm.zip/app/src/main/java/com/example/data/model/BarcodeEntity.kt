package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "barcodes")
data class BarcodeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val code: String,
    val format: String = "BARCODE_OR_QR",
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
