package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BarcodeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BarcodeDao {
    @Query("SELECT * FROM barcodes ORDER BY createdAt DESC")
    fun getAllBarcodes(): Flow<List<BarcodeEntity>>

    @Query("SELECT * FROM barcodes WHERE id = :id LIMIT 1")
    suspend fun getBarcodeById(id: Long): BarcodeEntity?

    @Query("SELECT * FROM barcodes WHERE code = :code LIMIT 1")
    suspend fun getBarcodeByCode(code: String): BarcodeEntity?

    @Query("SELECT COUNT(*) FROM barcodes")
    suspend fun getBarcodeCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBarcode(barcode: BarcodeEntity): Long

    @Update
    suspend fun updateBarcode(barcode: BarcodeEntity)

    @Delete
    suspend fun deleteBarcode(barcode: BarcodeEntity)
}
