package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SoundPreferences(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("scanwake_sound_prefs", Context.MODE_PRIVATE)

    private val _soundTypeFlow = MutableStateFlow(getSoundType())
    val soundTypeFlow: StateFlow<String> = _soundTypeFlow.asStateFlow()

    private val _customSoundTitleFlow = MutableStateFlow(getCustomSoundTitle())
    val customSoundTitleFlow: StateFlow<String> = _customSoundTitleFlow.asStateFlow()

    private val _alarmVolumeFlow = MutableStateFlow(getAlarmVolume())
    val alarmVolumeFlow: StateFlow<Float> = _alarmVolumeFlow.asStateFlow()

    private val _snoozeDurationSecondsFlow = MutableStateFlow(getSnoozeDurationSeconds())
    val snoozeDurationSecondsFlow: StateFlow<Int> = _snoozeDurationSecondsFlow.asStateFlow()

    private val _alarmFadeInFlow = MutableStateFlow(getAlarmFadeIn())
    val alarmFadeInFlow: StateFlow<Boolean> = _alarmFadeInFlow.asStateFlow()

    fun getAlarmFadeIn(): Boolean {
        return prefs.getBoolean(KEY_ALARM_FADE_IN, false)
    }

    fun setAlarmFadeIn(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ALARM_FADE_IN, enabled).apply()
        _alarmFadeInFlow.value = enabled
    }

    fun getSnoozeDurationSeconds(): Int {
        return prefs.getInt(KEY_SNOOZE_DURATION_SEC, 60) // default 1 minute
    }

    fun setSnoozeDurationSeconds(seconds: Int) {
        val clamped = seconds.coerceIn(10, 3600)
        prefs.edit().putInt(KEY_SNOOZE_DURATION_SEC, clamped).apply()
        _snoozeDurationSecondsFlow.value = clamped
    }

    fun getSnoozeDurationDisplay(seconds: Int = getSnoozeDurationSeconds()): String {
        return when (seconds) {
            30 -> "30 seconds"
            60 -> "1 minute"
            120 -> "2 minutes"
            180 -> "3 minutes"
            300 -> "5 minutes"
            600 -> "10 minutes"
            else -> if (seconds < 60) "$seconds seconds" else "${seconds / 60} min"
        }
    }

    fun getSoundType(): String {
        return prefs.getString(KEY_SOUND_TYPE, TYPE_RADAR_PULSE) ?: TYPE_RADAR_PULSE
    }

    fun setSoundType(type: String) {
        prefs.edit().putString(KEY_SOUND_TYPE, type).apply()
        _soundTypeFlow.value = type
    }

    fun getCustomSoundTitle(): String {
        return prefs.getString(KEY_CUSTOM_TITLE, "My Audio File") ?: "My Audio File"
    }

    fun getCustomSoundPath(): String? {
        return prefs.getString(KEY_CUSTOM_PATH, null)
    }

    fun setCustomSound(title: String, path: String) {
        prefs.edit()
            .putString(KEY_CUSTOM_TITLE, title)
            .putString(KEY_CUSTOM_PATH, path)
            .putString(KEY_SOUND_TYPE, TYPE_CUSTOM_FILE)
            .apply()
        _customSoundTitleFlow.value = title
        _soundTypeFlow.value = TYPE_CUSTOM_FILE
    }

    fun getAlarmVolume(): Float {
        return prefs.getFloat(KEY_ALARM_VOLUME, 1.0f)
    }

    fun setAlarmVolume(volume: Float) {
        val clamped = volume.coerceIn(0.1f, 1.0f)
        prefs.edit().putFloat(KEY_ALARM_VOLUME, clamped).apply()
        _alarmVolumeFlow.value = clamped
    }

    fun getSoundDisplayName(type: String = getSoundType()): String {
        return when (type) {
            TYPE_SYSTEM_DEFAULT -> "System Default Alarm"
            TYPE_RADAR_PULSE -> "Radar Pulse (High Urgency)"
            TYPE_DIGITAL_BEEP -> "Digital Clock Beep"
            TYPE_EMERGENCY_SIREN -> "Emergency Siren"
            TYPE_ENERGETIC_WAKE -> "Energetic Wake Beat"
            TYPE_CUSTOM_FILE -> "Custom: ${getCustomSoundTitle()}"
            else -> "Default Tone"
        }
    }

    companion object {
        const val KEY_SOUND_TYPE = "key_alarm_sound_type"
        const val KEY_CUSTOM_TITLE = "key_custom_sound_title"
        const val KEY_CUSTOM_PATH = "key_custom_sound_path"
        const val KEY_ALARM_VOLUME = "key_alarm_volume"
        const val KEY_SNOOZE_DURATION_SEC = "key_snooze_duration_sec"
        const val KEY_ALARM_FADE_IN = "key_alarm_fade_in"

        const val TYPE_SYSTEM_DEFAULT = "SYSTEM_DEFAULT"
        const val TYPE_RADAR_PULSE = "RADAR_PULSE"
        const val TYPE_DIGITAL_BEEP = "DIGITAL_BEEP"
        const val TYPE_EMERGENCY_SIREN = "EMERGENCY_SIREN"
        const val TYPE_ENERGETIC_WAKE = "ENERGETIC_WAKE"
        const val TYPE_CUSTOM_FILE = "CUSTOM_FILE"

        val BUILT_IN_SOUNDS = listOf(
            TYPE_RADAR_PULSE,
            TYPE_DIGITAL_BEEP,
            TYPE_EMERGENCY_SIREN,
            TYPE_ENERGETIC_WAKE,
            TYPE_SYSTEM_DEFAULT
        )
    }
}
