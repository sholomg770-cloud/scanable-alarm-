package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AlarmDao
import com.example.data.dao.BarcodeDao
import com.example.data.model.AlarmEntity
import com.example.data.model.BarcodeEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [BarcodeEntity::class, AlarmEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun barcodeDao(): BarcodeDao
    abstract fun alarmDao(): AlarmDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "scanwake_database"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.barcodeDao(), database.alarmDao())
                    }
                }
            }
        }

        private suspend fun populateInitialData(barcodeDao: BarcodeDao, alarmDao: AlarmDao) {
            // Seed 2 convenient initial barcodes
            val defaultBarcodeId = barcodeDao.insertBarcode(
                BarcodeEntity(
                    name = "Bathroom Toothpaste 🪥",
                    code = "79400262108",
                    format = "UPC_A",
                    isDefault = true
                )
            )

            barcodeDao.insertBarcode(
                BarcodeEntity(
                    name = "Kitchen Coffee Can ☕",
                    code = "011110853408",
                    format = "UPC_A",
                    isDefault = false
                )
            )

            // Seed an initial demo alarm for 7:00 AM
            alarmDao.insertAlarm(
                AlarmEntity(
                    timeHour = 7,
                    timeMinute = 0,
                    label = "Morning Kickstart",
                    isEnabled = false,
                    repeatDays = 0b0011111, // Weekdays Mon-Fri
                    targetBarcodeId = defaultBarcodeId,
                    vibrate = true,
                    preventTurnOffShield = true
                )
            )
        }
    }
}
